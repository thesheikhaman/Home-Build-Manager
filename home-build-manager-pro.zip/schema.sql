-- Run in Supabase SQL Editor. This simple version supports one private app owner.
create extension if not exists pgcrypto;
create table if not exists public.shops (id text primary key, name text not null, type text, phone text, created_at timestamptz default now());
create table if not exists public.materials (id text primary key, name text not null, group_name text, rate numeric(14,2) default 0, unit text, shop_id text references public.shops(id) on delete set null, active boolean default true, created_at timestamptz default now());
create table if not exists public.purchases (id text primary key, purchase_date date not null, shop_id text references public.shops(id), material_id text references public.materials(id), quantity numeric(14,3), rate numeric(14,2), fare numeric(14,2) default 0, reference text, notes text, created_at timestamptz default now());
create table if not exists public.ledger_entries (id text primary key, entry_date date not null, shop_id text references public.shops(id), entry_type text check(entry_type in ('credit','debit')), amount numeric(14,2) not null, category text, notes text, created_at timestamptz default now());
alter table public.shops enable row level security; alter table public.materials enable row level security; alter table public.purchases enable row level security; alter table public.ledger_entries enable row level security;
-- For public-key use without login. For production, replace with authenticated-user policies.
create policy "anon shops" on public.shops for all to anon using (true) with check (true);
create policy "anon materials" on public.materials for all to anon using (true) with check (true);
create policy "anon purchases" on public.purchases for all to anon using (true) with check (true);
create policy "anon ledger" on public.ledger_entries for all to anon using (true) with check (true);
