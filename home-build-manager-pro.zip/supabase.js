const SUPABASE_URL='https://lgynvylwyhezfdhukedy.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_RIx2l4KZttYhCwyzyZb7lQ_4huAF8KU';
const db=window.supabase?.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
async function testCloud(){if(!db)return{ok:false,message:'Supabase library unavailable'};const{error}=await db.from('shops').select('id').limit(1);return{ok:!error,message:error?error.message:'Supabase connected'};}
async function cloudLoad(table){const{data,error}=await db.from(table).select('*');if(error)throw error;return data||[];}
async function cloudSave(table,row){const{data,error}=await db.from(table).upsert(row).select();if(error)throw error;return data;}
async function cloudDelete(table,id){const{error}=await db.from(table).delete().eq('id',id);if(error)throw error;}
